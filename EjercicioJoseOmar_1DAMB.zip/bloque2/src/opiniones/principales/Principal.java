/* clase principal donde se piden todas las cosas */
package opiniones.principales;

import opiniones.datos.Criticas;
import opiniones.datos.Negocio;
import opiniones.datos.Usuario;

import java.util.Arrays;
import java.util.Scanner;

public class Principal
{
    public static void main(String[] args)
    {
        Scanner sc = new Scanner(System.in);
        Management management = new Management();

        String usuario, pass, negocio, comentario;
        Usuario usu;

        int opcion, elecnegocio, nota;
        boolean encontrado;

        management.initialize();

        do{
            System.out.println("dime el usuario:");
            usuario = sc.nextLine();

            System.out.println("dime la contraseña");
            pass = sc.nextLine();

             management.Login(usuario, pass);
             encontrado = true;

             usu = management.Login(usuario, pass);

        }
        while (management.Login(usuario, pass) == null);


        if (encontrado=true)
        {
            do {
                System.out.println("Dime la opciones que quieres elegir");
                System.out.println("1. My reviews \n" +
                        "2. Business list.\n" +
                        "3. Top rated businesses \n" +
                        "4. Edit my review \n");


                opcion = sc.nextInt();
                switch(opcion) {
                    case 1:
                        management.showReviews(usuario); ;
                        break;
                    case 2:
                       management.sortBusinessesByName();
                        break;
                    case 3:
                        System.out.println(" 1 para restaurantes, 2 \n" +
                                "para peluquerías y 3 para garajes");
                        elecnegocio = sc.nextInt();
                        management.sortBusinessesByRating(elecnegocio);
                        break;
                    case 4:
                        System.out.println("Nombre negocio:");
                        negocio = sc.next();
                        Negocio ne = management.findBusiness(negocio);
                        Criticas cr = management.findReview(usu, ne);
                        if (ne != null && cr != null)
                        {
                            System.out.println(ne);
                            System.out.println(cr);
                            System.out.println("nuevo comentario");
                            comentario = sc.next();
                            System.out.println("Dime una puntuacion");
                            nota = sc.nextInt();

                            management.changeReview(cr, comentario, nota);

                        }
                        break;
                    default:
                        System.out.println("Incorrect");
                }


            }while (opcion!=0);

        }


    }

}
