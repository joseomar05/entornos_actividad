/* Aqui se inicializan todas las clases y se hacen los metodos */

package opiniones.principales;
import java.util.Arrays;
import opiniones.datos.*;

import java.awt.*;
import java.util.Locale;
import java.util.Scanner;

public class Management
{

    protected Usuario[] usuarios;
    protected Criticas[] comentarios;
    protected Negocio[] negocios;

    public void initialize()
    {
        usuarios = new Usuario[10];
        usuarios[0] = new Usuario("u0",  "u0");
        usuarios[1] = new Usuario("usuario1",  "1111");
        usuarios[2] = new Usuario("usuario2",  "2222");
        usuarios[3] = new Usuario("usuario3",  "3333");
        usuarios[4] = new Usuario("usuario4",  "4444");
        usuarios[5] = new Usuario("usuario5",  "5555");
        usuarios[6] = new Usuario("usuario6",  "6666");
        usuarios[7] = new Usuario("usuario7",  "7777");
        usuarios[8] = new Usuario("usuario8",  "8888");
        usuarios[9] = new Usuario("usuario9",  "9999");


        comentarios = new Criticas[12];
        comentarios[0] = new Criticas(usuarios[0], "comentrario0", 4);
        comentarios[1] = new Criticas(usuarios[1], "comentrario1", 5);
        comentarios[2] = new Criticas(usuarios[2], "comentrario2", 2);
        comentarios[3] = new Criticas(usuarios[3], "comentrario3", 3);
        comentarios[4] = new Criticas(usuarios[4], "comentrario4", 4);
        comentarios[5] = new Criticas(usuarios[5], "comentrario5", 5);
        comentarios[6] = new Criticas(usuarios[6], "comentrario6", 2);
        comentarios[7] = new Criticas(usuarios[7], "comentrario7", 3);
        comentarios[8] = new Criticas(usuarios[8], "comentrario8", 4);
        comentarios[9] = new Criticas(usuarios[9], "comentrario9", 5);
        comentarios[10] = new Criticas(usuarios[1], "comentrario10", 2);
        comentarios[11] = new Criticas(usuarios[2], "comentrario11", 3);


        negocios = new Negocio[6];
        negocios[0] = new Restaurante("restaurante1",  "ubi1",
                new Criticas[]{comentarios[0],comentarios[1]}, "comida1");

        negocios[1] = new Restaurante("restaurante2",  "ubi2",
                new Criticas[]{comentarios[2],comentarios[3]},"comida2");

        negocios[2] = new Peluquero("peluqueria3",  "ubi3",
                new Criticas[]{comentarios[3],comentarios[4]},true);

        negocios[3] = new Peluquero("peluqueria4",  "ubi4",
                new Criticas[]{comentarios[5],comentarios[6]},false);

        negocios[4] = new Garaje("Garaje5",  "ubi5",
                new Criticas[]{comentarios[7],comentarios[8]},  22);

        negocios[5] = new Garaje("Garage6",  "ubi6",
                new Criticas[]{comentarios[9],comentarios[10]}, 50);


    }
    public void showReviews(String us)
    {
        for (int i=0; i < comentarios.length; i++)
        {
            if (us.equals(comentarios[i].getUsuarioAsociado().getLogin()))
            {
                System.out.println(comentarios[i]);
            }
        }
    }
    public void sortBusinessesByName()
    {
        Arrays.sort(negocios);

        System.out.printf(Arrays.toString(negocios));
        //negocios.toString();

    }
    public Usuario Login(String usu, String pass)
    {

        for (int i=0; i < usuarios.length; i++)
        {

            if (usu.equals(usuarios[i].getLogin())  && pass.equals(usuarios[i].getPassword()))
            {
                return usuarios[i];
            }
        }
        return null;
    }

    public void mostrar() {
        for (int i = 0; i < comentarios.length; i++)
        {
            System.out.println(comentarios[i]);
        }
    }

    public void sortBusinessesByRating(float type)
    {
        for (int i =0; i< negocios.length; i++)
        {
            if (type == 1)
            {
                if (negocios[i].getClass()==Restaurante.class)
                {
                    System.out.println(negocios[i].toString());
                }
            }
            else if (type ==2)
            {
                if (negocios[i].getClass()==Peluquero.class)
                {
                    System.out.println(negocios[i].toString());
                }
            }

            else if (type ==3)
            {
                if (negocios[i].getClass()==Garaje.class)
                {
                    System.out.println(negocios[i].toString());
                }
            }
        }

    }

    public Negocio findBusiness(String name)
    {
        for (int i=0; i < negocios.length; i++)
        {

            if (name.toUpperCase().equals(negocios[i].getNombre().toUpperCase()))
            {
                return negocios[i];
            }
        }
        return null;
    }

    public Criticas findReview(Usuario user, Negocio business)
    {
        for (int i=0; i< negocios.length; i++)
        {
            if (user.getLogin().equals(usuarios[i].getLogin()) && business.getNombre().equals(negocios[i].getNombre()))
            {
                return comentarios[i];
            }
        }
        return null;
    }

    public void changeReview(Criticas r, String comment, int rating)
    {
        for(int i=0; i< comentarios.length; i++)
        {
            if (r.getComentario().equals(comentarios[i].getComentario()) &&
                    r.getCalificación()==(comentarios[i].getCalificación()))
            {
                comentarios[i].setComentario(comment);
                comentarios[i].setCalificación(rating);
                System.out.println("Nuevo");
                System.out.println(comentarios[i].toString());
            }
        }
    }

}
