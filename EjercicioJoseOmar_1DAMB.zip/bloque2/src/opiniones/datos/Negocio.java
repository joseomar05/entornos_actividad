/* Clase Padre de donde se hereda */

package opiniones.datos;

abstract public class Negocio implements Comparable<Negocio>
{
    protected String nombre;
    protected String ubicacion;
    protected Criticas[] criticas;


    public Negocio(String nombre, String ubicacion, Criticas[] criticas) {
        this.nombre = nombre;
        this.ubicacion = ubicacion;
        this.criticas = criticas;
    }
    public Negocio(String nombre, String ubicacion) {
        this.nombre = nombre;
        this.ubicacion = ubicacion;
    }
    public float reviewAverage()
    {

        float total=0;

        for(int i=0; i<criticas.length; i++)
        {
          total = criticas[i].getCalificación() + total;
        }
        total = total / criticas.length;

        return total;
    }
    public Criticas[] getCriticas() {
        return criticas;
    }

    public String getNombre() {
        return nombre;
    }

    public void setNombre(String nombre) {
        this.nombre = nombre;
    }

    public String getUbicacion() {
        return ubicacion;
    }

    public void setUbicacion(String ubicacion) {
        this.ubicacion = ubicacion;
    }

    @Override
    public int compareTo(Negocio o) {
        if (this.nombre.charAt(0) > o.getNombre().charAt(0))
        {
            return -1;
        }
        else if (this.nombre.charAt(0) < o.getNombre().charAt(0))
        {
            return 1;
        }
        else
        {
            return 0;
        }

    }

    @Override
    public String toString() {
        return nombre +" (" + ubicacion+ ") \n" ;
    }




}
