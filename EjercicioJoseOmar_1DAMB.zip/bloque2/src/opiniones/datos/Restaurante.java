/* Clase Restuarante de donde se hereda de Negocio */
package opiniones.datos;

public class Restaurante extends Negocio
{
    protected String tipoComida;

    public Restaurante(String nombre, String ubicacion, Criticas[] criticas, String tipoComida)
    {
        super(nombre, ubicacion, criticas);
        this.tipoComida = tipoComida;
    }


    public String getTipoComida() {
        return tipoComida;
    }

    public void setTipoComida(String tipoComida) {
        this.tipoComida = tipoComida;
    }

    @Override
    public String toString() {
        return "Restautante " + super.toString() + " - "
                + tipoComida + '\'' + "Review average: " + reviewAverage();
    }
}
