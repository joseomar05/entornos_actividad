/* Clase Criticas estan atributos de las criticas */

package opiniones.datos;

public class Criticas
{
    protected Usuario usuarioAso;
    protected String comentario;
    protected int calificación;

    public Criticas(Usuario usuarioAso, String comentario, int calificación)
    {
        this.usuarioAso = usuarioAso;
        this.comentario = comentario;
        if (calificación <=5 && calificación>=0)
        {
           this.calificación = calificación;
        }

    }

    public Usuario getUsuarioAsociado() {
        return usuarioAso;
    }

    public void setUsuarioAsociado(Usuario usuarioAso) {
        this.usuarioAso = usuarioAso;
    }

    public String getComentario() {
        return comentario;
    }

    public void setComentario(String comentario) {
        this.comentario = comentario;
    }

    public int getCalificación()
     {
        return calificación;
    }

    public void setCalificación(int calificación)
    {
        if (calificación <=5 && calificación>=0)
        {
            this.calificación = calificación;
        }

    }

    @Override
    public String toString() {
        return "Critica{" +
                "usuarioAso=" + usuarioAso +
                ", comentario='" + comentario + '\'' +
                ", calificación=" + calificación +
                '}';
    }
}
