/* Clase Garaje de donde se hereda de Negocio */
package opiniones.datos;

public class Garaje extends Negocio
{
    protected float precio;


    public Garaje(String nombre, String ubicacion, Criticas[] criticas, float precio) {
        super(nombre, ubicacion, criticas);
        this.precio = precio;
    }

    public float getPrecio() {
        return precio;
    }

    public void setPrecio(float precio) {
        this.precio = precio;
    }

    @Override
    public String toString() {
        return "Garaje " + super.toString() + " - " + precio + "eur/h"
                + '\'' + "Review average: " + reviewAverage();
    }
}