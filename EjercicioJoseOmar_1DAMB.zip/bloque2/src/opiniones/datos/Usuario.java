/* Clase usuario donde se ponen los atributes de los usuarios */
package opiniones.datos;

public class Usuario
{
    protected String login;
    protected String password;

    public Usuario(String login, String password)
    {
        this.login = login;
        this.password = password;
    }

    public String getLogin() {
        return login;
    }

    public String getPassword() {
        return password;
    }

    @Override
    public String toString() {
        return "Usuario{" +
                "login='" + login + '\'' +
                ", password='" + password + '\'' +
                '}';
    }
}
