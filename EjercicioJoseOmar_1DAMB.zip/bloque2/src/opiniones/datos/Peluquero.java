/* Clase Peluqueria de donde se hereda de Negocio */

package opiniones.datos;

public class Peluquero extends Negocio
{
  protected boolean tipo;


    public Peluquero(String nombre, String ubicacion, Criticas[] criticas, boolean tipo) {
        super(nombre, ubicacion, criticas);
        this.tipo = tipo;
    }

    public boolean getTipo() {
        return tipo;
    }

    public void setTipo(boolean tipo) {
        this.tipo = tipo;
    }

    @Override
    public String toString() {
        if (getTipo()==true)
        {
            return "Peluqueria " + super.toString() + " - Unisex"
                    + '\'' + "Review average: " + reviewAverage();
        }
        return "Peluqueria " + super.toString() + " - No-unisex"
                + '\'' + "Review average: " + reviewAverage();

    }
}
